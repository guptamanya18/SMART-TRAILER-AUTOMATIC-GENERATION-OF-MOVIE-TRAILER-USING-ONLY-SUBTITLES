# Smart Trailer
Automatic trailer generation using subtitles.
